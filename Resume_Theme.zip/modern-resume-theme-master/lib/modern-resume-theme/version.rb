module ModernResumeTheme
  VERSION = "1.5.3"
end
